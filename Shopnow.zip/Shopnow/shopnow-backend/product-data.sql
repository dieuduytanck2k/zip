INSERT INTO public.product (id,category,description,"name",price) VALUES
	 (3,'Thời trang nữ','Màu sắc thực của mặt hàng có thể hơi khác so với hình ảnh hiển thị trên trang web','Áo len ren màu hồng cardigan nữ',200000),
	 (2,'Điện thoại','IPhone 15 Pro Max là sản phẩm cao cấp nhất trong bộ sưu tập 15 series loại xin đó','Điện thoại Apple iPhone 15 Pro Max 256GB',29690000),
	 (4,'Giày dép nữ','một phiên bản mới của mẫu giày huyền thoại Air Jordan 1, mang thiết kế sắc nét và đầy tính biểu tượng. Được lấy cảm hứng từ những màu sắc của đội bóng rổ','Nike Air Jordan 1 Mid Chicago Toe Like Auth',1190000),
	 (5,'Điện thoại','MacBook Pro 14 inch M4 2024 là một trong những mẫu laptop cao cấp của Apple, được trang bị các tính năng mạnh mẽ và cải tiến so với các phiên bản trước. Dưới đây là một số điểm nổi bật của nó','MacBook Pro 14 inch M4 2024',40000000),
	 (6,'Sắc đẹp','Emmié Soothing & Hydrating Derma Cleansing chính là Gel rửa mặt B5 chuyên dụng tại SPA, hoàn hảo cho da siêu nhạy cảm và sau điều trị.','Gel Rửa Mặt Emmié Soothing',280000),
	 (7,'Thời trang nữ','Chiếc quần legging với thiết kế cao cấp, cách điệu cạp chéo, nữ tính. Được may trên nền 3 chất liệu: cotton, polyester và rayon với tỉ lệ hoàn hảo giúp người mặc thoải mái vận động tập thể thao hay đi chơi.','Quần Tập Gym Nữ Cạp Chéo',299000),
	 (8,'Thời trang','Đế dép thường được thiết kế chống trượt, giúp di chuyển an toàn trên sàn nhà','Dép đi trong nhà siêu xinh nam nữ',387000),
	 (9,'Thiết bị điện tử','Công nghệ UltraMix hòa tan bột giặt trước khi giặt nâng cao hiệu quả giặt Công nghệ AutoDose tự động phân bổ chính xác lượng nước giặt, nước xả','Máy giặt Electrolux Inverter 11 kg',15690000);
